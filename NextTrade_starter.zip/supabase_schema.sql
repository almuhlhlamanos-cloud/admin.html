-- NextTrade starter schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'user' check (role in ('user','admin')),
  kyc_status text not null default 'not_submitted'
    check (kyc_status in ('not_submitted','pending','verified','rejected')),
  created_at timestamptz not null default now()
);

create table if not exists public.requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  request_type text not null check (request_type in ('deposit','withdrawal','investment','kyc')),
  amount numeric(18,2),
  asset text,
  network text,
  wallet_address text,
  tx_hash text,
  full_name text,
  status text not null default 'pending'
    check (status in ('pending','approved','rejected','completed')),
  admin_note text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

create index if not exists requests_user_id_created_at_idx
  on public.requests(user_id, created_at desc);
create index if not exists requests_status_created_at_idx
  on public.requests(status, created_at desc);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name',''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = (select auth.uid()) and p.role = 'admin'
  );
$$;

alter table public.profiles enable row level security;
alter table public.requests enable row level security;

drop policy if exists "profile read self or admin" on public.profiles;
create policy "profile read self or admin" on public.profiles
for select to authenticated using (id = (select auth.uid()) or public.is_admin());

drop policy if exists "profile update self limited" on public.profiles;
create policy "profile update self limited" on public.profiles
for update to authenticated using (id = (select auth.uid()))
with check (id = (select auth.uid()) and role = 'user');

drop policy if exists "request read owner or admin" on public.requests;
create policy "request read owner or admin" on public.requests
for select to authenticated using (user_id = (select auth.uid()) or public.is_admin());

drop policy if exists "request create own" on public.requests;
create policy "request create own" on public.requests
for insert to authenticated with check (
  user_id = (select auth.uid()) and status = 'pending'
);

drop policy if exists "admin update requests" on public.requests;
create policy "admin update requests" on public.requests
for update to authenticated using (public.is_admin()) with check (public.is_admin());

grant usage on schema public to authenticated;
grant select, update on public.profiles to authenticated;
grant select, insert, update on public.requests to authenticated;
